﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Soduko_AI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var sudoku = new int[,]{
                { -1, -2, -3, -4, -5, -6, -7, -8, -9 },
                { -11, -12, -13, -14, -15, -16, -17, -18, -19 },
                { -21, -22, -23, -24, -25, -26, -27, -28, -29 },
                { -31, -32, -33, -34, -35, -36, -37, -38, -39 },
                { -41, -42, -43, -44, -45, -46, -47, -48, -49 },
                { -51, -52, -53, -54, -55, -56, -57, -58, -59 },
                { -61, -62, -63, -64, -65, -66, -67, -68, -69 },
                { -71, -72, -73, -74, -75, -76, -77, -78, -79 },
                { -81, -82, -83, -84, -85, -86, -87, -88, -89 }};

            //This next part makes the array board
            //the if true is to shrink everything down
            if (true)
            {
                int a;
                //Changes to origanal form
                for (int i = 8; i >= 0; i--)
                {
                    for (int r = 0; r >= 8; r++)
                    {
                        sudoku[i, r] = -1*((i * 10) + r);
                    }
                }

                //Changes to user
                if (Int32.TryParse(A1.Text, out a)) { sudoku[0, 0] = Int32.Parse(A1.Text); }
                if (Int32.TryParse(B1.Text, out a)) { sudoku[0, 1] = Int32.Parse(B1.Text); }
                if (Int32.TryParse(C1.Text, out a)) { sudoku[0, 2] = Int32.Parse(C1.Text); }
                if (Int32.TryParse(D1.Text, out a)) { sudoku[0, 3] = Int32.Parse(D1.Text); }
                if (Int32.TryParse(E1.Text, out a)) { sudoku[0, 4] = Int32.Parse(E1.Text); }
                if (Int32.TryParse(F1.Text, out a)) { sudoku[0, 5] = Int32.Parse(F1.Text); }
                if (Int32.TryParse(G1.Text, out a)) { sudoku[0, 6] = Int32.Parse(G1.Text); }
                if (Int32.TryParse(H1.Text, out a)) { sudoku[0, 7] = Int32.Parse(H1.Text); }
                if (Int32.TryParse(I1.Text, out a)) { sudoku[0, 8] = Int32.Parse(I1.Text); }
                if (Int32.TryParse(A2.Text, out a)) { sudoku[1, 0] = Int32.Parse(A2.Text); }
                if (Int32.TryParse(B2.Text, out a)) { sudoku[1, 1] = Int32.Parse(B2.Text); }
                if (Int32.TryParse(C2.Text, out a)) { sudoku[1, 2] = Int32.Parse(C2.Text); }
                if (Int32.TryParse(D2.Text, out a)) { sudoku[1, 3] = Int32.Parse(D2.Text); }
                if (Int32.TryParse(E2.Text, out a)) { sudoku[1, 4] = Int32.Parse(E2.Text); }
                if (Int32.TryParse(F2.Text, out a)) { sudoku[1, 5] = Int32.Parse(F2.Text); }
                if (Int32.TryParse(G2.Text, out a)) { sudoku[1, 6] = Int32.Parse(G2.Text); }
                if (Int32.TryParse(H2.Text, out a)) { sudoku[1, 7] = Int32.Parse(H2.Text); }
                if (Int32.TryParse(I2.Text, out a)) { sudoku[1, 8] = Int32.Parse(I2.Text); }
                if (Int32.TryParse(A3.Text, out a)) { sudoku[2, 0] = Int32.Parse(A3.Text); }
                if (Int32.TryParse(B3.Text, out a)) { sudoku[2, 1] = Int32.Parse(B3.Text); }
                if (Int32.TryParse(C3.Text, out a)) { sudoku[2, 2] = Int32.Parse(C3.Text); }
                if (Int32.TryParse(D3.Text, out a)) { sudoku[2, 3] = Int32.Parse(D3.Text); }
                if (Int32.TryParse(E3.Text, out a)) { sudoku[2, 4] = Int32.Parse(E3.Text); }
                if (Int32.TryParse(F3.Text, out a)) { sudoku[2, 5] = Int32.Parse(F3.Text); }
                if (Int32.TryParse(G3.Text, out a)) { sudoku[2, 6] = Int32.Parse(G3.Text); }
                if (Int32.TryParse(H3.Text, out a)) { sudoku[2, 7] = Int32.Parse(H3.Text); }
                if (Int32.TryParse(I3.Text, out a)) { sudoku[2, 8] = Int32.Parse(I3.Text); }
                if (Int32.TryParse(A4.Text, out a)) { sudoku[3, 0] = Int32.Parse(A4.Text); }
                if (Int32.TryParse(B4.Text, out a)) { sudoku[3, 1] = Int32.Parse(B4.Text); }
                if (Int32.TryParse(C4.Text, out a)) { sudoku[3, 2] = Int32.Parse(C4.Text); }
                if (Int32.TryParse(D4.Text, out a)) { sudoku[3, 3] = Int32.Parse(D4.Text); }
                if (Int32.TryParse(E4.Text, out a)) { sudoku[3, 4] = Int32.Parse(E4.Text); }
                if (Int32.TryParse(F4.Text, out a)) { sudoku[3, 5] = Int32.Parse(F4.Text); }
                if (Int32.TryParse(G4.Text, out a)) { sudoku[3, 6] = Int32.Parse(G4.Text); }
                if (Int32.TryParse(H4.Text, out a)) { sudoku[3, 7] = Int32.Parse(H4.Text); }
                if (Int32.TryParse(I4.Text, out a)) { sudoku[3, 8] = Int32.Parse(I4.Text); }
                if (Int32.TryParse(A5.Text, out a)) { sudoku[4, 0] = Int32.Parse(A5.Text); }
                if (Int32.TryParse(B5.Text, out a)) { sudoku[4, 1] = Int32.Parse(B5.Text); }
                if (Int32.TryParse(C5.Text, out a)) { sudoku[4, 2] = Int32.Parse(C5.Text); }
                if (Int32.TryParse(D5.Text, out a)) { sudoku[4, 3] = Int32.Parse(D5.Text); }
                if (Int32.TryParse(E5.Text, out a)) { sudoku[4, 4] = Int32.Parse(E5.Text); }
                if (Int32.TryParse(F5.Text, out a)) { sudoku[4, 5] = Int32.Parse(F5.Text); }
                if (Int32.TryParse(G5.Text, out a)) { sudoku[4, 6] = Int32.Parse(G5.Text); }
                if (Int32.TryParse(H5.Text, out a)) { sudoku[4, 7] = Int32.Parse(H5.Text); }
                if (Int32.TryParse(I5.Text, out a)) { sudoku[4, 8] = Int32.Parse(I5.Text); }
                if (Int32.TryParse(A6.Text, out a)) { sudoku[5, 0] = Int32.Parse(A6.Text); }
                if (Int32.TryParse(B6.Text, out a)) { sudoku[5, 1] = Int32.Parse(B6.Text); }
                if (Int32.TryParse(C6.Text, out a)) { sudoku[5, 2] = Int32.Parse(C6.Text); }
                if (Int32.TryParse(D6.Text, out a)) { sudoku[5, 3] = Int32.Parse(D6.Text); }
                if (Int32.TryParse(E6.Text, out a)) { sudoku[5, 4] = Int32.Parse(E6.Text); }
                if (Int32.TryParse(F6.Text, out a)) { sudoku[5, 5] = Int32.Parse(F6.Text); }
                if (Int32.TryParse(G6.Text, out a)) { sudoku[5, 6] = Int32.Parse(G6.Text); }
                if (Int32.TryParse(H6.Text, out a)) { sudoku[5, 7] = Int32.Parse(H6.Text); }
                if (Int32.TryParse(I6.Text, out a)) { sudoku[5, 8] = Int32.Parse(I6.Text); }
                if (Int32.TryParse(A7.Text, out a)) { sudoku[6, 0] = Int32.Parse(A7.Text); }
                if (Int32.TryParse(B7.Text, out a)) { sudoku[6, 1] = Int32.Parse(B7.Text); }
                if (Int32.TryParse(C7.Text, out a)) { sudoku[6, 2] = Int32.Parse(C7.Text); }
                if (Int32.TryParse(D7.Text, out a)) { sudoku[6, 3] = Int32.Parse(D7.Text); }
                if (Int32.TryParse(E7.Text, out a)) { sudoku[6, 4] = Int32.Parse(E7.Text); }
                if (Int32.TryParse(F7.Text, out a)) { sudoku[6, 5] = Int32.Parse(F7.Text); }
                if (Int32.TryParse(G7.Text, out a)) { sudoku[6, 6] = Int32.Parse(G7.Text); }
                if (Int32.TryParse(H7.Text, out a)) { sudoku[6, 7] = Int32.Parse(H7.Text); }
                if (Int32.TryParse(I7.Text, out a)) { sudoku[6, 8] = Int32.Parse(I7.Text); }
                if (Int32.TryParse(A8.Text, out a)) { sudoku[7, 0] = Int32.Parse(A8.Text); }
                if (Int32.TryParse(B8.Text, out a)) { sudoku[7, 1] = Int32.Parse(B8.Text); }
                if (Int32.TryParse(C8.Text, out a)) { sudoku[7, 2] = Int32.Parse(C8.Text); }
                if (Int32.TryParse(D8.Text, out a)) { sudoku[7, 3] = Int32.Parse(D8.Text); }
                if (Int32.TryParse(E8.Text, out a)) { sudoku[7, 4] = Int32.Parse(E8.Text); }
                if (Int32.TryParse(F8.Text, out a)) { sudoku[7, 5] = Int32.Parse(F8.Text); }
                if (Int32.TryParse(G8.Text, out a)) { sudoku[7, 6] = Int32.Parse(G8.Text); }
                if (Int32.TryParse(H8.Text, out a)) { sudoku[7, 7] = Int32.Parse(H8.Text); }
                if (Int32.TryParse(I8.Text, out a)) { sudoku[7, 8] = Int32.Parse(I8.Text); }
                if (Int32.TryParse(A9.Text, out a)) { sudoku[8, 0] = Int32.Parse(A9.Text); }
                if (Int32.TryParse(B9.Text, out a)) { sudoku[8, 1] = Int32.Parse(B9.Text); }
                if (Int32.TryParse(C9.Text, out a)) { sudoku[8, 2] = Int32.Parse(C9.Text); }
                if (Int32.TryParse(D9.Text, out a)) { sudoku[8, 3] = Int32.Parse(D9.Text); }
                if (Int32.TryParse(E9.Text, out a)) { sudoku[8, 4] = Int32.Parse(E9.Text); }
                if (Int32.TryParse(F9.Text, out a)) { sudoku[8, 5] = Int32.Parse(F9.Text); }
                if (Int32.TryParse(G9.Text, out a)) { sudoku[8, 6] = Int32.Parse(G9.Text); }
                if (Int32.TryParse(H9.Text, out a)) { sudoku[8, 7] = Int32.Parse(H9.Text); }
                if (Int32.TryParse(I9.Text, out a)) { sudoku[8, 8] = Int32.Parse(I9.Text); }
            }
            //Checks if there are Duplicates horizontaly
            for (int r = 8; r >= 0; r--)
            {
                List<int> numbers = new List<int>();
                numbers.Add(0);
                for (int i = 8; i >= 0; i--)
                {
                    numbers.Add(sudoku[r, i]);
                }
                if (numbers.Count != numbers.Distinct().Count())
                {
                    Console.WriteLine("Dups");
                }
                numbers.Clear();
            }
            //Checks if there are Dups Verticaly
            for (int r = 8; r >= 0; r--)
            {
                List<int> numbers2 = new List<int>();
                numbers2.Add(0);
                for (int i = 8; i >= 0; i--)
                {
                    numbers2.Add(sudoku[i, r]);
                }
                if (numbers2.Count != numbers2.Distinct().Count())
                {
                    Console.WriteLine("Dups");
                }
                numbers2.Clear();
            }
            //This grabs the boxes - Next 2 for loops
            for (int i = 0; i <= 100; i++)
            {
                for (int z = 0; z <= 8; z++)
                {
                    for (int x = 0; x <= 8; x++)
                    {
                        if (sudoku[z, x] <= 0)
                        {
                            List<int> numbers = new List<int>();
                            List<int> Onethroughnine = new List<int>();
                            //Inputs the numbers 1-9
                            for (int w = 1; w <= 9; w++)
                            {
                                Onethroughnine.Add(w);
                            }
                            //Gets the Boxes Horizontaly
                            for (int t = 0; t <= 8; t++)
                            {
                                //goes through each box
                                numbers.Add(sudoku[z, t]);
                            }
                            //Gets the Boxes Verticly
                            for (int t = 0; t <= 8; t++)
                            {
                                //goes through each box
                                numbers.Add(sudoku[t, x]);
                            }
                            //Cells
                            //This Fixes a bug
                            if (i <= 81)
                            {
                                //Gets the Cell That the Block is in
                                if (z <= 2 && x <= 2)
                                {
                                    for (int r = 0; r <= 2; r++)
                                    {
                                        for (int t = 0; t <= 2; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z <= 2 && x >= 3 && x <= 5)
                                {
                                    //R is Z
                                    for (int r = 0; r <= 2; r++)
                                    {
                                        //T is X
                                        for (int t = 3; t <= 5; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z >= 3 && z <= 5 && x <= 3)
                                {
                                    for (int r = 3; r <= 5; r++)
                                    {
                                        for (int t = 0; t <= 2; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z >= 3 && z <= 5 && x >= 3 && x <= 5)
                                {
                                    for (int r = 3; r <= 5; r++)
                                    {
                                        for (int t = 3; t <= 5; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z >= 3 && z <= 5 && x >= 6)
                                {
                                    //R is Z
                                    for (int r = 3; r <= 5; r++)
                                    {
                                        //T is X
                                        for (int t = 6; t <= 8; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z >= 6 && x >= 6)
                                {
                                    for (int r = 6; r <= 8; r++)
                                    {
                                        for (int t = 6; t <= 8; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                                if (z >= 6 && x >= 3 && x <= 5)
                                {
                                    //R is Z
                                    for (int r = 6; r <= 8; r++)
                                    {
                                        //T is X
                                        for (int t = 3; t <= 5; t++)
                                        {
                                            if (sudoku[r, t] >= 1)
                                            {
                                                numbers.Add(sudoku[r, t]);
                                            }
                                        }
                                    }
                                }
                            }
                            //removes all of the numbers that the number would not be
                            foreach (int num in numbers)
                            {
                                //removes from list
                                if (Onethroughnine.Contains(num))
                                {
                                    Onethroughnine.Remove(num);
                                }
                            }
                            //if the list of number left is just one then it inputs that number
                            if (Onethroughnine.Count() == 1)
                            {
                                sudoku[z, x] = Onethroughnine[0];
                                if (z == 0 && x == 0)
                                {
                                    A1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 1)
                                {
                                    B1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 2)
                                {
                                    C1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 3)
                                {
                                    D1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 4)
                                {
                                    E1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 5)
                                {
                                    F1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 6)
                                {
                                    G1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 7)
                                {
                                    H1.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 0 && x == 8)
                                {
                                    I1.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 1 && x == 0)
                                {
                                    A2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 1)
                                {
                                    B2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 2)
                                {
                                    C2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 3)
                                {
                                    D2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 4)
                                {
                                    E2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 5)
                                {
                                    F2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 6)
                                {
                                    G2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 7)
                                {
                                    H2.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 1 && x == 8)
                                {
                                    I2.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 2 && x == 0)
                                {
                                    A3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 1)
                                {
                                    B3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 2)
                                {
                                    C3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 3)
                                {
                                    D3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 4)
                                {
                                    E3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 5)
                                {
                                    F3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 6)
                                {
                                    G3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 7)
                                {
                                    H3.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 2 && x == 8)
                                {
                                    I3.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 3 && x == 0)
                                {
                                    A4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 1)
                                {
                                    B4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 2)
                                {
                                    C4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 3)
                                {
                                    D4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 4)
                                {
                                    E4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 5)
                                {
                                    F4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 6)
                                {
                                    G4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 7)
                                {
                                    H4.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 3 && x == 8)
                                {
                                    I4.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 4 && x == 0)
                                {
                                    A5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 1)
                                {
                                    B5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 2)
                                {
                                    C5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 3)
                                {
                                    D5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 4)
                                {
                                    E5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 5)
                                {
                                    F5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 6)
                                {
                                    G5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 7)
                                {
                                    H5.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 4 && x == 8)
                                {
                                    I5.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 5 && x == 0)
                                {
                                    A6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 1)
                                {
                                    B6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 2)
                                {
                                    C6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 3)
                                {
                                    D6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 4)
                                {
                                    E6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 5)
                                {
                                    F6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 6)
                                {
                                    G6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 7)
                                {
                                    H6.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 5 && x == 8)
                                {
                                    I6.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 6 && x == 0)
                                {
                                    A7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 1)
                                {
                                    B7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 2)
                                {
                                    C7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 3)
                                {
                                    D7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 4)
                                {
                                    E7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 5)
                                {
                                    F7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 6)
                                {
                                    G7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 7)
                                {
                                    H7.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 6 && x == 8)
                                {
                                    I7.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 7 && x == 0)
                                {
                                    A8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 1)
                                {
                                    B8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 2)
                                {
                                    C8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 3)
                                {
                                    D8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 4)
                                {
                                    E8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 5)
                                {
                                    F8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 6)
                                {
                                    G8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 7)
                                {
                                    H8.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 7 && x == 8)
                                {
                                    I8.Text = Onethroughnine[0].ToString();
                                }
                                if (z == 8 && x == 0)
                                {
                                    A9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 1)
                                {
                                    B9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 2)
                                {
                                    C9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 3)
                                {
                                    D9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 4)
                                {
                                    E9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 5)
                                {
                                    F9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 6)
                                {
                                    G9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 7)
                                {
                                    H9.Text = Onethroughnine[0].ToString();
                                }
                                else if (z == 8 && x == 8)
                                {
                                    I9.Text = Onethroughnine[0].ToString();
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}