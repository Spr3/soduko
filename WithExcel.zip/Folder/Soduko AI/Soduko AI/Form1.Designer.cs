﻿
namespace Soduko_AI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.A1 = new System.Windows.Forms.TextBox();
            this.B1 = new System.Windows.Forms.TextBox();
            this.C1 = new System.Windows.Forms.TextBox();
            this.F1 = new System.Windows.Forms.TextBox();
            this.E1 = new System.Windows.Forms.TextBox();
            this.D1 = new System.Windows.Forms.TextBox();
            this.I1 = new System.Windows.Forms.TextBox();
            this.H1 = new System.Windows.Forms.TextBox();
            this.G1 = new System.Windows.Forms.TextBox();
            this.I2 = new System.Windows.Forms.TextBox();
            this.H2 = new System.Windows.Forms.TextBox();
            this.G2 = new System.Windows.Forms.TextBox();
            this.F2 = new System.Windows.Forms.TextBox();
            this.E2 = new System.Windows.Forms.TextBox();
            this.D2 = new System.Windows.Forms.TextBox();
            this.C2 = new System.Windows.Forms.TextBox();
            this.B2 = new System.Windows.Forms.TextBox();
            this.A2 = new System.Windows.Forms.TextBox();
            this.I3 = new System.Windows.Forms.TextBox();
            this.H3 = new System.Windows.Forms.TextBox();
            this.G3 = new System.Windows.Forms.TextBox();
            this.F3 = new System.Windows.Forms.TextBox();
            this.E3 = new System.Windows.Forms.TextBox();
            this.D3 = new System.Windows.Forms.TextBox();
            this.C3 = new System.Windows.Forms.TextBox();
            this.B3 = new System.Windows.Forms.TextBox();
            this.A3 = new System.Windows.Forms.TextBox();
            this.I4 = new System.Windows.Forms.TextBox();
            this.H4 = new System.Windows.Forms.TextBox();
            this.G4 = new System.Windows.Forms.TextBox();
            this.F4 = new System.Windows.Forms.TextBox();
            this.E4 = new System.Windows.Forms.TextBox();
            this.D4 = new System.Windows.Forms.TextBox();
            this.C4 = new System.Windows.Forms.TextBox();
            this.B4 = new System.Windows.Forms.TextBox();
            this.A4 = new System.Windows.Forms.TextBox();
            this.I5 = new System.Windows.Forms.TextBox();
            this.H5 = new System.Windows.Forms.TextBox();
            this.G5 = new System.Windows.Forms.TextBox();
            this.F5 = new System.Windows.Forms.TextBox();
            this.E5 = new System.Windows.Forms.TextBox();
            this.D5 = new System.Windows.Forms.TextBox();
            this.C5 = new System.Windows.Forms.TextBox();
            this.B5 = new System.Windows.Forms.TextBox();
            this.A5 = new System.Windows.Forms.TextBox();
            this.I6 = new System.Windows.Forms.TextBox();
            this.H6 = new System.Windows.Forms.TextBox();
            this.G6 = new System.Windows.Forms.TextBox();
            this.F6 = new System.Windows.Forms.TextBox();
            this.E6 = new System.Windows.Forms.TextBox();
            this.D6 = new System.Windows.Forms.TextBox();
            this.C6 = new System.Windows.Forms.TextBox();
            this.B6 = new System.Windows.Forms.TextBox();
            this.A6 = new System.Windows.Forms.TextBox();
            this.I9 = new System.Windows.Forms.TextBox();
            this.H9 = new System.Windows.Forms.TextBox();
            this.G9 = new System.Windows.Forms.TextBox();
            this.F9 = new System.Windows.Forms.TextBox();
            this.E9 = new System.Windows.Forms.TextBox();
            this.D9 = new System.Windows.Forms.TextBox();
            this.C9 = new System.Windows.Forms.TextBox();
            this.B9 = new System.Windows.Forms.TextBox();
            this.A9 = new System.Windows.Forms.TextBox();
            this.I8 = new System.Windows.Forms.TextBox();
            this.H8 = new System.Windows.Forms.TextBox();
            this.G8 = new System.Windows.Forms.TextBox();
            this.F8 = new System.Windows.Forms.TextBox();
            this.E8 = new System.Windows.Forms.TextBox();
            this.D8 = new System.Windows.Forms.TextBox();
            this.C8 = new System.Windows.Forms.TextBox();
            this.B8 = new System.Windows.Forms.TextBox();
            this.A8 = new System.Windows.Forms.TextBox();
            this.I7 = new System.Windows.Forms.TextBox();
            this.H7 = new System.Windows.Forms.TextBox();
            this.G7 = new System.Windows.Forms.TextBox();
            this.F7 = new System.Windows.Forms.TextBox();
            this.E7 = new System.Windows.Forms.TextBox();
            this.D7 = new System.Windows.Forms.TextBox();
            this.C7 = new System.Windows.Forms.TextBox();
            this.B7 = new System.Windows.Forms.TextBox();
            this.A7 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // A1
            // 
            this.A1.BackColor = System.Drawing.Color.LightGray;
            this.A1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A1.Location = new System.Drawing.Point(12, 12);
            this.A1.Multiline = true;
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(23, 25);
            this.A1.TabIndex = 0;
            this.A1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B1
            // 
            this.B1.BackColor = System.Drawing.Color.LightGray;
            this.B1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B1.Location = new System.Drawing.Point(41, 12);
            this.B1.Multiline = true;
            this.B1.Name = "B1";
            this.B1.Size = new System.Drawing.Size(23, 25);
            this.B1.TabIndex = 1;
            this.B1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C1
            // 
            this.C1.BackColor = System.Drawing.Color.LightGray;
            this.C1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1.Location = new System.Drawing.Point(70, 12);
            this.C1.Multiline = true;
            this.C1.Name = "C1";
            this.C1.Size = new System.Drawing.Size(23, 25);
            this.C1.TabIndex = 2;
            this.C1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F1
            // 
            this.F1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F1.Location = new System.Drawing.Point(155, 12);
            this.F1.Multiline = true;
            this.F1.Name = "F1";
            this.F1.Size = new System.Drawing.Size(23, 25);
            this.F1.TabIndex = 5;
            this.F1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E1
            // 
            this.E1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E1.Location = new System.Drawing.Point(126, 12);
            this.E1.Multiline = true;
            this.E1.Name = "E1";
            this.E1.Size = new System.Drawing.Size(23, 25);
            this.E1.TabIndex = 4;
            this.E1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D1
            // 
            this.D1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D1.Location = new System.Drawing.Point(97, 12);
            this.D1.Multiline = true;
            this.D1.Name = "D1";
            this.D1.Size = new System.Drawing.Size(23, 25);
            this.D1.TabIndex = 3;
            this.D1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I1
            // 
            this.I1.BackColor = System.Drawing.Color.LightGray;
            this.I1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I1.Location = new System.Drawing.Point(240, 12);
            this.I1.Multiline = true;
            this.I1.Name = "I1";
            this.I1.Size = new System.Drawing.Size(23, 25);
            this.I1.TabIndex = 8;
            this.I1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H1
            // 
            this.H1.BackColor = System.Drawing.Color.LightGray;
            this.H1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H1.Location = new System.Drawing.Point(211, 12);
            this.H1.Multiline = true;
            this.H1.Name = "H1";
            this.H1.Size = new System.Drawing.Size(23, 25);
            this.H1.TabIndex = 7;
            this.H1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G1
            // 
            this.G1.BackColor = System.Drawing.Color.LightGray;
            this.G1.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G1.Location = new System.Drawing.Point(182, 12);
            this.G1.Multiline = true;
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(23, 25);
            this.G1.TabIndex = 6;
            this.G1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I2
            // 
            this.I2.BackColor = System.Drawing.Color.LightGray;
            this.I2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I2.Location = new System.Drawing.Point(240, 43);
            this.I2.Multiline = true;
            this.I2.Name = "I2";
            this.I2.Size = new System.Drawing.Size(23, 25);
            this.I2.TabIndex = 17;
            this.I2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H2
            // 
            this.H2.BackColor = System.Drawing.Color.LightGray;
            this.H2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H2.Location = new System.Drawing.Point(211, 43);
            this.H2.Multiline = true;
            this.H2.Name = "H2";
            this.H2.Size = new System.Drawing.Size(23, 25);
            this.H2.TabIndex = 16;
            this.H2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G2
            // 
            this.G2.BackColor = System.Drawing.Color.LightGray;
            this.G2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G2.Location = new System.Drawing.Point(182, 43);
            this.G2.Multiline = true;
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(23, 25);
            this.G2.TabIndex = 15;
            this.G2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F2
            // 
            this.F2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F2.Location = new System.Drawing.Point(155, 43);
            this.F2.Multiline = true;
            this.F2.Name = "F2";
            this.F2.Size = new System.Drawing.Size(23, 25);
            this.F2.TabIndex = 14;
            this.F2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E2
            // 
            this.E2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E2.Location = new System.Drawing.Point(126, 43);
            this.E2.Multiline = true;
            this.E2.Name = "E2";
            this.E2.Size = new System.Drawing.Size(23, 25);
            this.E2.TabIndex = 13;
            this.E2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D2
            // 
            this.D2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D2.Location = new System.Drawing.Point(97, 43);
            this.D2.Multiline = true;
            this.D2.Name = "D2";
            this.D2.Size = new System.Drawing.Size(23, 25);
            this.D2.TabIndex = 12;
            this.D2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C2
            // 
            this.C2.BackColor = System.Drawing.Color.LightGray;
            this.C2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2.Location = new System.Drawing.Point(70, 43);
            this.C2.Multiline = true;
            this.C2.Name = "C2";
            this.C2.Size = new System.Drawing.Size(23, 25);
            this.C2.TabIndex = 11;
            this.C2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B2
            // 
            this.B2.BackColor = System.Drawing.Color.LightGray;
            this.B2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B2.Location = new System.Drawing.Point(41, 43);
            this.B2.Multiline = true;
            this.B2.Name = "B2";
            this.B2.Size = new System.Drawing.Size(23, 25);
            this.B2.TabIndex = 10;
            this.B2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A2
            // 
            this.A2.BackColor = System.Drawing.Color.LightGray;
            this.A2.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A2.Location = new System.Drawing.Point(12, 43);
            this.A2.Multiline = true;
            this.A2.Name = "A2";
            this.A2.Size = new System.Drawing.Size(23, 25);
            this.A2.TabIndex = 9;
            this.A2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I3
            // 
            this.I3.BackColor = System.Drawing.Color.LightGray;
            this.I3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I3.Location = new System.Drawing.Point(240, 74);
            this.I3.Multiline = true;
            this.I3.Name = "I3";
            this.I3.Size = new System.Drawing.Size(23, 25);
            this.I3.TabIndex = 26;
            this.I3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H3
            // 
            this.H3.BackColor = System.Drawing.Color.LightGray;
            this.H3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H3.Location = new System.Drawing.Point(211, 74);
            this.H3.Multiline = true;
            this.H3.Name = "H3";
            this.H3.Size = new System.Drawing.Size(23, 25);
            this.H3.TabIndex = 25;
            this.H3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G3
            // 
            this.G3.BackColor = System.Drawing.Color.LightGray;
            this.G3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G3.Location = new System.Drawing.Point(182, 74);
            this.G3.Multiline = true;
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(23, 25);
            this.G3.TabIndex = 24;
            this.G3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F3
            // 
            this.F3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F3.Location = new System.Drawing.Point(155, 74);
            this.F3.Multiline = true;
            this.F3.Name = "F3";
            this.F3.Size = new System.Drawing.Size(23, 25);
            this.F3.TabIndex = 23;
            this.F3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E3
            // 
            this.E3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E3.Location = new System.Drawing.Point(126, 74);
            this.E3.Multiline = true;
            this.E3.Name = "E3";
            this.E3.Size = new System.Drawing.Size(23, 25);
            this.E3.TabIndex = 22;
            this.E3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D3
            // 
            this.D3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D3.Location = new System.Drawing.Point(97, 74);
            this.D3.Multiline = true;
            this.D3.Name = "D3";
            this.D3.Size = new System.Drawing.Size(23, 25);
            this.D3.TabIndex = 21;
            this.D3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C3
            // 
            this.C3.BackColor = System.Drawing.Color.LightGray;
            this.C3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3.Location = new System.Drawing.Point(70, 74);
            this.C3.Multiline = true;
            this.C3.Name = "C3";
            this.C3.Size = new System.Drawing.Size(23, 25);
            this.C3.TabIndex = 20;
            this.C3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B3
            // 
            this.B3.BackColor = System.Drawing.Color.LightGray;
            this.B3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B3.Location = new System.Drawing.Point(41, 74);
            this.B3.Multiline = true;
            this.B3.Name = "B3";
            this.B3.Size = new System.Drawing.Size(23, 25);
            this.B3.TabIndex = 19;
            this.B3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A3
            // 
            this.A3.BackColor = System.Drawing.Color.LightGray;
            this.A3.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A3.Location = new System.Drawing.Point(12, 74);
            this.A3.Multiline = true;
            this.A3.Name = "A3";
            this.A3.Size = new System.Drawing.Size(23, 25);
            this.A3.TabIndex = 18;
            this.A3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I4
            // 
            this.I4.BackColor = System.Drawing.Color.White;
            this.I4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I4.Location = new System.Drawing.Point(240, 105);
            this.I4.Multiline = true;
            this.I4.Name = "I4";
            this.I4.Size = new System.Drawing.Size(23, 25);
            this.I4.TabIndex = 35;
            this.I4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H4
            // 
            this.H4.BackColor = System.Drawing.Color.White;
            this.H4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H4.Location = new System.Drawing.Point(211, 105);
            this.H4.Multiline = true;
            this.H4.Name = "H4";
            this.H4.Size = new System.Drawing.Size(23, 25);
            this.H4.TabIndex = 34;
            this.H4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G4
            // 
            this.G4.BackColor = System.Drawing.Color.White;
            this.G4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G4.Location = new System.Drawing.Point(182, 105);
            this.G4.Multiline = true;
            this.G4.Name = "G4";
            this.G4.Size = new System.Drawing.Size(23, 25);
            this.G4.TabIndex = 33;
            this.G4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F4
            // 
            this.F4.BackColor = System.Drawing.Color.LightGray;
            this.F4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F4.Location = new System.Drawing.Point(155, 105);
            this.F4.Multiline = true;
            this.F4.Name = "F4";
            this.F4.Size = new System.Drawing.Size(23, 25);
            this.F4.TabIndex = 32;
            this.F4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E4
            // 
            this.E4.BackColor = System.Drawing.Color.LightGray;
            this.E4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E4.Location = new System.Drawing.Point(126, 105);
            this.E4.Multiline = true;
            this.E4.Name = "E4";
            this.E4.Size = new System.Drawing.Size(23, 25);
            this.E4.TabIndex = 31;
            this.E4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D4
            // 
            this.D4.BackColor = System.Drawing.Color.LightGray;
            this.D4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D4.Location = new System.Drawing.Point(97, 105);
            this.D4.Multiline = true;
            this.D4.Name = "D4";
            this.D4.Size = new System.Drawing.Size(23, 25);
            this.D4.TabIndex = 30;
            this.D4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C4
            // 
            this.C4.BackColor = System.Drawing.Color.White;
            this.C4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C4.Location = new System.Drawing.Point(70, 105);
            this.C4.Multiline = true;
            this.C4.Name = "C4";
            this.C4.Size = new System.Drawing.Size(23, 25);
            this.C4.TabIndex = 29;
            this.C4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B4
            // 
            this.B4.BackColor = System.Drawing.Color.White;
            this.B4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B4.Location = new System.Drawing.Point(41, 105);
            this.B4.Multiline = true;
            this.B4.Name = "B4";
            this.B4.Size = new System.Drawing.Size(23, 25);
            this.B4.TabIndex = 28;
            this.B4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A4
            // 
            this.A4.BackColor = System.Drawing.Color.White;
            this.A4.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A4.Location = new System.Drawing.Point(12, 105);
            this.A4.Multiline = true;
            this.A4.Name = "A4";
            this.A4.Size = new System.Drawing.Size(23, 25);
            this.A4.TabIndex = 27;
            this.A4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I5
            // 
            this.I5.BackColor = System.Drawing.Color.White;
            this.I5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I5.Location = new System.Drawing.Point(240, 136);
            this.I5.Multiline = true;
            this.I5.Name = "I5";
            this.I5.Size = new System.Drawing.Size(23, 25);
            this.I5.TabIndex = 44;
            this.I5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H5
            // 
            this.H5.BackColor = System.Drawing.Color.White;
            this.H5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H5.Location = new System.Drawing.Point(211, 136);
            this.H5.Multiline = true;
            this.H5.Name = "H5";
            this.H5.Size = new System.Drawing.Size(23, 25);
            this.H5.TabIndex = 43;
            this.H5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G5
            // 
            this.G5.BackColor = System.Drawing.Color.White;
            this.G5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G5.Location = new System.Drawing.Point(182, 136);
            this.G5.Multiline = true;
            this.G5.Name = "G5";
            this.G5.Size = new System.Drawing.Size(23, 25);
            this.G5.TabIndex = 42;
            this.G5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F5
            // 
            this.F5.BackColor = System.Drawing.Color.LightGray;
            this.F5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F5.Location = new System.Drawing.Point(155, 136);
            this.F5.Multiline = true;
            this.F5.Name = "F5";
            this.F5.Size = new System.Drawing.Size(23, 25);
            this.F5.TabIndex = 41;
            this.F5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E5
            // 
            this.E5.BackColor = System.Drawing.Color.LightGray;
            this.E5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E5.Location = new System.Drawing.Point(126, 136);
            this.E5.Multiline = true;
            this.E5.Name = "E5";
            this.E5.Size = new System.Drawing.Size(23, 25);
            this.E5.TabIndex = 40;
            this.E5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D5
            // 
            this.D5.BackColor = System.Drawing.Color.LightGray;
            this.D5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D5.Location = new System.Drawing.Point(97, 136);
            this.D5.Multiline = true;
            this.D5.Name = "D5";
            this.D5.Size = new System.Drawing.Size(23, 25);
            this.D5.TabIndex = 39;
            this.D5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C5
            // 
            this.C5.BackColor = System.Drawing.Color.White;
            this.C5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C5.Location = new System.Drawing.Point(70, 136);
            this.C5.Multiline = true;
            this.C5.Name = "C5";
            this.C5.Size = new System.Drawing.Size(23, 25);
            this.C5.TabIndex = 38;
            this.C5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B5
            // 
            this.B5.BackColor = System.Drawing.Color.White;
            this.B5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B5.Location = new System.Drawing.Point(41, 136);
            this.B5.Multiline = true;
            this.B5.Name = "B5";
            this.B5.Size = new System.Drawing.Size(23, 25);
            this.B5.TabIndex = 37;
            this.B5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A5
            // 
            this.A5.BackColor = System.Drawing.Color.White;
            this.A5.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A5.Location = new System.Drawing.Point(12, 136);
            this.A5.Multiline = true;
            this.A5.Name = "A5";
            this.A5.Size = new System.Drawing.Size(23, 25);
            this.A5.TabIndex = 36;
            this.A5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I6
            // 
            this.I6.BackColor = System.Drawing.Color.White;
            this.I6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I6.Location = new System.Drawing.Point(240, 167);
            this.I6.Multiline = true;
            this.I6.Name = "I6";
            this.I6.Size = new System.Drawing.Size(23, 25);
            this.I6.TabIndex = 53;
            this.I6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H6
            // 
            this.H6.BackColor = System.Drawing.Color.White;
            this.H6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H6.Location = new System.Drawing.Point(211, 167);
            this.H6.Multiline = true;
            this.H6.Name = "H6";
            this.H6.Size = new System.Drawing.Size(23, 25);
            this.H6.TabIndex = 52;
            this.H6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G6
            // 
            this.G6.BackColor = System.Drawing.Color.White;
            this.G6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G6.Location = new System.Drawing.Point(182, 167);
            this.G6.Multiline = true;
            this.G6.Name = "G6";
            this.G6.Size = new System.Drawing.Size(23, 25);
            this.G6.TabIndex = 51;
            this.G6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F6
            // 
            this.F6.BackColor = System.Drawing.Color.LightGray;
            this.F6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F6.Location = new System.Drawing.Point(155, 167);
            this.F6.Multiline = true;
            this.F6.Name = "F6";
            this.F6.Size = new System.Drawing.Size(23, 25);
            this.F6.TabIndex = 50;
            this.F6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E6
            // 
            this.E6.BackColor = System.Drawing.Color.LightGray;
            this.E6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E6.Location = new System.Drawing.Point(126, 167);
            this.E6.Multiline = true;
            this.E6.Name = "E6";
            this.E6.Size = new System.Drawing.Size(23, 25);
            this.E6.TabIndex = 49;
            this.E6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D6
            // 
            this.D6.BackColor = System.Drawing.Color.LightGray;
            this.D6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D6.Location = new System.Drawing.Point(97, 167);
            this.D6.Multiline = true;
            this.D6.Name = "D6";
            this.D6.Size = new System.Drawing.Size(23, 25);
            this.D6.TabIndex = 48;
            this.D6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C6
            // 
            this.C6.BackColor = System.Drawing.Color.White;
            this.C6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C6.Location = new System.Drawing.Point(70, 167);
            this.C6.Multiline = true;
            this.C6.Name = "C6";
            this.C6.Size = new System.Drawing.Size(23, 25);
            this.C6.TabIndex = 47;
            this.C6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B6
            // 
            this.B6.BackColor = System.Drawing.Color.White;
            this.B6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B6.Location = new System.Drawing.Point(41, 167);
            this.B6.Multiline = true;
            this.B6.Name = "B6";
            this.B6.Size = new System.Drawing.Size(23, 25);
            this.B6.TabIndex = 46;
            this.B6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A6
            // 
            this.A6.BackColor = System.Drawing.Color.White;
            this.A6.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A6.Location = new System.Drawing.Point(12, 167);
            this.A6.Multiline = true;
            this.A6.Name = "A6";
            this.A6.Size = new System.Drawing.Size(23, 25);
            this.A6.TabIndex = 45;
            this.A6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I9
            // 
            this.I9.BackColor = System.Drawing.Color.LightGray;
            this.I9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I9.Location = new System.Drawing.Point(240, 260);
            this.I9.Multiline = true;
            this.I9.Name = "I9";
            this.I9.Size = new System.Drawing.Size(23, 25);
            this.I9.TabIndex = 80;
            this.I9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H9
            // 
            this.H9.BackColor = System.Drawing.Color.LightGray;
            this.H9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H9.Location = new System.Drawing.Point(211, 260);
            this.H9.Multiline = true;
            this.H9.Name = "H9";
            this.H9.Size = new System.Drawing.Size(23, 25);
            this.H9.TabIndex = 79;
            this.H9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G9
            // 
            this.G9.BackColor = System.Drawing.Color.LightGray;
            this.G9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G9.Location = new System.Drawing.Point(182, 260);
            this.G9.Multiline = true;
            this.G9.Name = "G9";
            this.G9.Size = new System.Drawing.Size(23, 25);
            this.G9.TabIndex = 78;
            this.G9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F9
            // 
            this.F9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F9.Location = new System.Drawing.Point(155, 260);
            this.F9.Multiline = true;
            this.F9.Name = "F9";
            this.F9.Size = new System.Drawing.Size(23, 25);
            this.F9.TabIndex = 77;
            this.F9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E9
            // 
            this.E9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E9.Location = new System.Drawing.Point(126, 260);
            this.E9.Multiline = true;
            this.E9.Name = "E9";
            this.E9.Size = new System.Drawing.Size(23, 25);
            this.E9.TabIndex = 76;
            this.E9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D9
            // 
            this.D9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D9.Location = new System.Drawing.Point(97, 260);
            this.D9.Multiline = true;
            this.D9.Name = "D9";
            this.D9.Size = new System.Drawing.Size(23, 25);
            this.D9.TabIndex = 75;
            this.D9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C9
            // 
            this.C9.BackColor = System.Drawing.Color.LightGray;
            this.C9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C9.Location = new System.Drawing.Point(70, 260);
            this.C9.Multiline = true;
            this.C9.Name = "C9";
            this.C9.Size = new System.Drawing.Size(23, 25);
            this.C9.TabIndex = 74;
            this.C9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B9
            // 
            this.B9.BackColor = System.Drawing.Color.LightGray;
            this.B9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B9.Location = new System.Drawing.Point(41, 260);
            this.B9.Multiline = true;
            this.B9.Name = "B9";
            this.B9.Size = new System.Drawing.Size(23, 25);
            this.B9.TabIndex = 73;
            this.B9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A9
            // 
            this.A9.BackColor = System.Drawing.Color.LightGray;
            this.A9.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A9.Location = new System.Drawing.Point(12, 260);
            this.A9.Multiline = true;
            this.A9.Name = "A9";
            this.A9.Size = new System.Drawing.Size(23, 25);
            this.A9.TabIndex = 72;
            this.A9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I8
            // 
            this.I8.BackColor = System.Drawing.Color.LightGray;
            this.I8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I8.Location = new System.Drawing.Point(240, 229);
            this.I8.Multiline = true;
            this.I8.Name = "I8";
            this.I8.Size = new System.Drawing.Size(23, 25);
            this.I8.TabIndex = 71;
            this.I8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H8
            // 
            this.H8.BackColor = System.Drawing.Color.LightGray;
            this.H8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H8.Location = new System.Drawing.Point(211, 229);
            this.H8.Multiline = true;
            this.H8.Name = "H8";
            this.H8.Size = new System.Drawing.Size(23, 25);
            this.H8.TabIndex = 70;
            this.H8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G8
            // 
            this.G8.BackColor = System.Drawing.Color.LightGray;
            this.G8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G8.Location = new System.Drawing.Point(182, 229);
            this.G8.Multiline = true;
            this.G8.Name = "G8";
            this.G8.Size = new System.Drawing.Size(23, 25);
            this.G8.TabIndex = 69;
            this.G8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F8
            // 
            this.F8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F8.Location = new System.Drawing.Point(155, 229);
            this.F8.Multiline = true;
            this.F8.Name = "F8";
            this.F8.Size = new System.Drawing.Size(23, 25);
            this.F8.TabIndex = 68;
            this.F8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E8
            // 
            this.E8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E8.Location = new System.Drawing.Point(126, 229);
            this.E8.Multiline = true;
            this.E8.Name = "E8";
            this.E8.Size = new System.Drawing.Size(23, 25);
            this.E8.TabIndex = 67;
            this.E8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D8
            // 
            this.D8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D8.Location = new System.Drawing.Point(97, 229);
            this.D8.Multiline = true;
            this.D8.Name = "D8";
            this.D8.Size = new System.Drawing.Size(23, 25);
            this.D8.TabIndex = 66;
            this.D8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C8
            // 
            this.C8.BackColor = System.Drawing.Color.LightGray;
            this.C8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C8.Location = new System.Drawing.Point(70, 229);
            this.C8.Multiline = true;
            this.C8.Name = "C8";
            this.C8.Size = new System.Drawing.Size(23, 25);
            this.C8.TabIndex = 65;
            this.C8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B8
            // 
            this.B8.BackColor = System.Drawing.Color.LightGray;
            this.B8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B8.Location = new System.Drawing.Point(41, 229);
            this.B8.Multiline = true;
            this.B8.Name = "B8";
            this.B8.Size = new System.Drawing.Size(23, 25);
            this.B8.TabIndex = 64;
            this.B8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A8
            // 
            this.A8.BackColor = System.Drawing.Color.LightGray;
            this.A8.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A8.Location = new System.Drawing.Point(12, 229);
            this.A8.Multiline = true;
            this.A8.Name = "A8";
            this.A8.Size = new System.Drawing.Size(23, 25);
            this.A8.TabIndex = 63;
            this.A8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // I7
            // 
            this.I7.BackColor = System.Drawing.Color.LightGray;
            this.I7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.I7.Location = new System.Drawing.Point(240, 198);
            this.I7.Multiline = true;
            this.I7.Name = "I7";
            this.I7.Size = new System.Drawing.Size(23, 25);
            this.I7.TabIndex = 62;
            this.I7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // H7
            // 
            this.H7.BackColor = System.Drawing.Color.LightGray;
            this.H7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.H7.Location = new System.Drawing.Point(211, 198);
            this.H7.Multiline = true;
            this.H7.Name = "H7";
            this.H7.Size = new System.Drawing.Size(23, 25);
            this.H7.TabIndex = 61;
            this.H7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // G7
            // 
            this.G7.BackColor = System.Drawing.Color.LightGray;
            this.G7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G7.Location = new System.Drawing.Point(182, 198);
            this.G7.Multiline = true;
            this.G7.Name = "G7";
            this.G7.Size = new System.Drawing.Size(23, 25);
            this.G7.TabIndex = 60;
            this.G7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // F7
            // 
            this.F7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F7.Location = new System.Drawing.Point(155, 198);
            this.F7.Multiline = true;
            this.F7.Name = "F7";
            this.F7.Size = new System.Drawing.Size(23, 25);
            this.F7.TabIndex = 59;
            this.F7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // E7
            // 
            this.E7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.E7.Location = new System.Drawing.Point(126, 198);
            this.E7.Multiline = true;
            this.E7.Name = "E7";
            this.E7.Size = new System.Drawing.Size(23, 25);
            this.E7.TabIndex = 58;
            this.E7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // D7
            // 
            this.D7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.D7.Location = new System.Drawing.Point(97, 198);
            this.D7.Multiline = true;
            this.D7.Name = "D7";
            this.D7.Size = new System.Drawing.Size(23, 25);
            this.D7.TabIndex = 57;
            this.D7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // C7
            // 
            this.C7.BackColor = System.Drawing.Color.LightGray;
            this.C7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C7.Location = new System.Drawing.Point(70, 198);
            this.C7.Multiline = true;
            this.C7.Name = "C7";
            this.C7.Size = new System.Drawing.Size(23, 25);
            this.C7.TabIndex = 56;
            this.C7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // B7
            // 
            this.B7.BackColor = System.Drawing.Color.LightGray;
            this.B7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.B7.Location = new System.Drawing.Point(41, 198);
            this.B7.Multiline = true;
            this.B7.Name = "B7";
            this.B7.Size = new System.Drawing.Size(23, 25);
            this.B7.TabIndex = 55;
            this.B7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // A7
            // 
            this.A7.BackColor = System.Drawing.Color.LightGray;
            this.A7.Font = new System.Drawing.Font("Microsoft YaHei", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.A7.Location = new System.Drawing.Point(12, 198);
            this.A7.Multiline = true;
            this.A7.Name = "A7";
            this.A7.Size = new System.Drawing.Size(23, 25);
            this.A7.TabIndex = 54;
            this.A7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 287);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(251, 23);
            this.button1.TabIndex = 81;
            this.button1.Text = "Solve";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 322);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.I9);
            this.Controls.Add(this.H9);
            this.Controls.Add(this.G9);
            this.Controls.Add(this.F9);
            this.Controls.Add(this.E9);
            this.Controls.Add(this.D9);
            this.Controls.Add(this.C9);
            this.Controls.Add(this.B9);
            this.Controls.Add(this.A9);
            this.Controls.Add(this.I8);
            this.Controls.Add(this.H8);
            this.Controls.Add(this.G8);
            this.Controls.Add(this.F8);
            this.Controls.Add(this.E8);
            this.Controls.Add(this.D8);
            this.Controls.Add(this.C8);
            this.Controls.Add(this.B8);
            this.Controls.Add(this.A8);
            this.Controls.Add(this.I7);
            this.Controls.Add(this.H7);
            this.Controls.Add(this.G7);
            this.Controls.Add(this.F7);
            this.Controls.Add(this.E7);
            this.Controls.Add(this.D7);
            this.Controls.Add(this.C7);
            this.Controls.Add(this.B7);
            this.Controls.Add(this.A7);
            this.Controls.Add(this.I6);
            this.Controls.Add(this.H6);
            this.Controls.Add(this.G6);
            this.Controls.Add(this.F6);
            this.Controls.Add(this.E6);
            this.Controls.Add(this.D6);
            this.Controls.Add(this.C6);
            this.Controls.Add(this.B6);
            this.Controls.Add(this.A6);
            this.Controls.Add(this.I5);
            this.Controls.Add(this.H5);
            this.Controls.Add(this.G5);
            this.Controls.Add(this.F5);
            this.Controls.Add(this.E5);
            this.Controls.Add(this.D5);
            this.Controls.Add(this.C5);
            this.Controls.Add(this.B5);
            this.Controls.Add(this.A5);
            this.Controls.Add(this.I4);
            this.Controls.Add(this.H4);
            this.Controls.Add(this.G4);
            this.Controls.Add(this.F4);
            this.Controls.Add(this.E4);
            this.Controls.Add(this.D4);
            this.Controls.Add(this.C4);
            this.Controls.Add(this.B4);
            this.Controls.Add(this.A4);
            this.Controls.Add(this.I3);
            this.Controls.Add(this.H3);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.F3);
            this.Controls.Add(this.E3);
            this.Controls.Add(this.D3);
            this.Controls.Add(this.C3);
            this.Controls.Add(this.B3);
            this.Controls.Add(this.A3);
            this.Controls.Add(this.I2);
            this.Controls.Add(this.H2);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.F2);
            this.Controls.Add(this.E2);
            this.Controls.Add(this.D2);
            this.Controls.Add(this.C2);
            this.Controls.Add(this.B2);
            this.Controls.Add(this.A2);
            this.Controls.Add(this.I1);
            this.Controls.Add(this.H1);
            this.Controls.Add(this.G1);
            this.Controls.Add(this.F1);
            this.Controls.Add(this.E1);
            this.Controls.Add(this.D1);
            this.Controls.Add(this.C1);
            this.Controls.Add(this.B1);
            this.Controls.Add(this.A1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox A1;
        private System.Windows.Forms.TextBox B1;
        private System.Windows.Forms.TextBox C1;
        private System.Windows.Forms.TextBox F1;
        private System.Windows.Forms.TextBox E1;
        private System.Windows.Forms.TextBox D1;
        private System.Windows.Forms.TextBox I1;
        private System.Windows.Forms.TextBox H1;
        private System.Windows.Forms.TextBox G1;
        private System.Windows.Forms.TextBox I2;
        private System.Windows.Forms.TextBox H2;
        private System.Windows.Forms.TextBox G2;
        private System.Windows.Forms.TextBox F2;
        private System.Windows.Forms.TextBox E2;
        private System.Windows.Forms.TextBox D2;
        private System.Windows.Forms.TextBox C2;
        private System.Windows.Forms.TextBox B2;
        private System.Windows.Forms.TextBox A2;
        private System.Windows.Forms.TextBox I3;
        private System.Windows.Forms.TextBox H3;
        private System.Windows.Forms.TextBox G3;
        private System.Windows.Forms.TextBox F3;
        private System.Windows.Forms.TextBox E3;
        private System.Windows.Forms.TextBox D3;
        private System.Windows.Forms.TextBox C3;
        private System.Windows.Forms.TextBox B3;
        private System.Windows.Forms.TextBox A3;
        private System.Windows.Forms.TextBox I4;
        private System.Windows.Forms.TextBox H4;
        private System.Windows.Forms.TextBox G4;
        private System.Windows.Forms.TextBox F4;
        private System.Windows.Forms.TextBox E4;
        private System.Windows.Forms.TextBox D4;
        private System.Windows.Forms.TextBox C4;
        private System.Windows.Forms.TextBox B4;
        private System.Windows.Forms.TextBox A4;
        private System.Windows.Forms.TextBox I5;
        private System.Windows.Forms.TextBox H5;
        private System.Windows.Forms.TextBox G5;
        private System.Windows.Forms.TextBox F5;
        private System.Windows.Forms.TextBox E5;
        private System.Windows.Forms.TextBox D5;
        private System.Windows.Forms.TextBox C5;
        private System.Windows.Forms.TextBox B5;
        private System.Windows.Forms.TextBox A5;
        private System.Windows.Forms.TextBox I6;
        private System.Windows.Forms.TextBox H6;
        private System.Windows.Forms.TextBox G6;
        private System.Windows.Forms.TextBox F6;
        private System.Windows.Forms.TextBox E6;
        private System.Windows.Forms.TextBox D6;
        private System.Windows.Forms.TextBox C6;
        private System.Windows.Forms.TextBox B6;
        private System.Windows.Forms.TextBox A6;
        private System.Windows.Forms.TextBox I9;
        private System.Windows.Forms.TextBox H9;
        private System.Windows.Forms.TextBox G9;
        private System.Windows.Forms.TextBox F9;
        private System.Windows.Forms.TextBox E9;
        private System.Windows.Forms.TextBox D9;
        private System.Windows.Forms.TextBox C9;
        private System.Windows.Forms.TextBox B9;
        private System.Windows.Forms.TextBox A9;
        private System.Windows.Forms.TextBox I8;
        private System.Windows.Forms.TextBox H8;
        private System.Windows.Forms.TextBox G8;
        private System.Windows.Forms.TextBox F8;
        private System.Windows.Forms.TextBox E8;
        private System.Windows.Forms.TextBox D8;
        private System.Windows.Forms.TextBox C8;
        private System.Windows.Forms.TextBox B8;
        private System.Windows.Forms.TextBox A8;
        private System.Windows.Forms.TextBox I7;
        private System.Windows.Forms.TextBox H7;
        private System.Windows.Forms.TextBox G7;
        private System.Windows.Forms.TextBox F7;
        private System.Windows.Forms.TextBox E7;
        private System.Windows.Forms.TextBox D7;
        private System.Windows.Forms.TextBox C7;
        private System.Windows.Forms.TextBox B7;
        private System.Windows.Forms.TextBox A7;
        private System.Windows.Forms.Button button1;
    }
}

